
public class Truck {
	
	private int _numTires;

	public int numTires(){
		
		return this._numTires = 4;
		
	}	
	
}
